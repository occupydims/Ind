rootProject.name = "RegularApp"
include(":app")
